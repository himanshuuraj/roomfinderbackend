package com.roomfinder.roomfinderconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomfinderConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomfinderConfigServerApplication.class, args);
	}

}
