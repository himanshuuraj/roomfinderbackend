package com.roomfinder.roomfinderzuulserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomfinderZuulServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomfinderZuulServerApplication.class, args);
	}

}
